
<?php
include 'config.php';
$phone = $_POST['phone'];
$password = $_POST['password'];
$invite = $_POST['invite_code'];
$sql = "INSERT INTO users (phone, password, invite_code) VALUES ('$phone', '$password', '$invite')";
if ($conn->query($sql) === TRUE) {
    echo "Registered successfully";
} else {
    echo "Error: " . $conn->error;
}
?>
