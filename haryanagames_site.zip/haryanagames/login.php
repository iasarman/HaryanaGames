
<?php
session_start();
include 'config.php';
$phone = $_POST['phone'];
$password = $_POST['password'];
$sql = "SELECT * FROM users WHERE phone='$phone' AND password='$password'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $_SESSION['phone'] = $phone;
    header("Location: dashboard.html");
} else {
    echo "Invalid login";
}
?>
